module Main where

import Scratchy as S

main :: IO ()
main = S.main
